/******************************************************************************

                            Online C Compiler.
                Code, Compile, Run and Debug C program online.
Write your code in this editor and press "Run" button to compile and execute it.

*******************************************************************************/

#include <stdio.h>

int main()
{
    int n,n1,r,rev=0;
    printf("enter a no.");
    scanf("%d",&n);
    n1=n;
    while(n!=0)
    {
        r=n%10;
        rev=rev*10+r;
        n=n/10;
    }
    if(rev==n1)
    {
        printf("Its a palindrome.");
    }
    else
    {
        printf("Not a palindrome");
    }
    return 0;
}